To ensure fonts are used properly by the theme, please copy the included ttf files to:
"/mnt/SDCARD/miyoo/app/" directory

Optionally, you can edit the config.json to point to the location of the iosevka ttf files on your device (or any other font you choose)